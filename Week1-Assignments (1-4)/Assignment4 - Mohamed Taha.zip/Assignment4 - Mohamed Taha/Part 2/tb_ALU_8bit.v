`timescale 1ns / 1ps

module tb_alu_8bit;

    reg  [7:0]  A;
    reg  [7:0]  B;
    reg         Cin;
    reg  [4:0]  Control;
    wire [15:0] Out;

    alu_8bit uut (
        .A(A),
        .B(B),
        .Cin(Cin),
        .Control(Control),
        .Out(Out)
    );

    integer i;

    initial begin
        A = 8'd20;
        B = 8'd5;
        Cin = 1'b1;

        for (i = 0; i < 24; i = i + 1) begin
            Control = i;
            #10;
        end

        A = 8'hFF; B = 8'h01; Control = 5'b00000; #10; 
        A = 8'h00; B = 8'h01; Control = 5'b00010; #10; 
        
        $finish;
    end
endmodule
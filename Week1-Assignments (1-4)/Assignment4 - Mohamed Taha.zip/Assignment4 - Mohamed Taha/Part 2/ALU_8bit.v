module alu_8bit (
    input  wire [7:0]  A,
    input  wire [7:0]  B,
    input  wire        Cin,
    input  wire [4:0]  Control,
    output reg  [15:0] Out
);
    always @(*) begin
        Out = 16'b0; 

        case (Control)
            5'b00000: Out = A + B;
            5'b00001: Out = A + B + Cin;
            5'b00010: Out = A + ~B + 1;
            5'b00011: Out = A + ~B;
            5'b00100: Out = A + 1;
            5'b00101: Out = A - 1;
            5'b00110: Out = (A * B) + 1;
            
            5'b00111: Out = A & B;
            5'b01000: Out = A | B;
            5'b01001: Out = A ^ B;
            5'b01010: Out = ~A;
            5'b01011: Out = ~(A & B);
            
            5'b01100: Out = {A[6:0], 1'b0}; 
            5'b01101: Out = A >> 1;
            5'b01110: Out = A << 1;
            5'b01111: Out = {A[7], A[7:1]}; 
            
            5'b10000: Out = {8'b0, A[0], A[7:1]}; 
            5'b10001: Out = {8'b0, A[6:0], A[7]}; 
            
            5'b10010: Out = (A > B) ? A : B;
            5'b10011: Out = Cin ? B : A;
            5'b10100: Out = {~A, ~B};
            
            5'b10101: Out = {10'b0, (A>=B), (A>B), (A==B), (A<=B), (A<B), (A!=B)};
            5'b10110: Out = {14'b0, ~^B, ^A};
            
            default:  Out = 16'b0;
        endcase
    end
endmodule
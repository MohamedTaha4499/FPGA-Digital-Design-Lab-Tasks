`timescale 1ns / 1ps

module tb_Data_Scrambler;

    reg  [7:0] data_in;
    reg  [1:0] scramble_key;
    reg  [1:0] op_mode;
    reg        sleep_mode;
    
    wire [7:0] data_out;
    wire       parity_err;
    wire       is_zero;

    Data_Scrambler uut (
        .data_in(data_in),
        .scramble_key(scramble_key),
        .op_mode(op_mode),
        .sleep_mode(sleep_mode),
        .data_out(data_out),
        .parity_err(parity_err),
        .is_zero(is_zero)
    );

    initial begin
        sleep_mode = 0;
        scramble_key = 2'b10;
        data_in = 8'b10001000; 
        
        op_mode = 2'b00; #10;
        op_mode = 2'b01; #10;
        op_mode = 2'b10; #10;
        op_mode = 2'b11; #10;
        
        sleep_mode = 1; #10;
        
        sleep_mode = 0;
        op_mode = 2'b00;
        data_in = 8'b00000000; #10;
        
        $finish;
    end
endmodule
`timescale 1ns / 1ps

module tb_full_adder;
  
    reg a;
    reg b;
    reg cin;

    wire sum_gate, cout_gate;
    wire sum_struct, cout_struct;
    wire sum_behav, cout_behav;
   
    full_adder_gate dut_gate (
        .a(a), .b(b), .cin(cin), 
        .sum(sum_gate), .cout(cout_gate)
    );

    full_adder_struct dut_struct (
        .a(a), .b(b), .cin(cin), 
        .sum(sum_struct), .cout(cout_struct)
    );
    
    full_adder_behav dut_behav (
        .a(a), .b(b), .cin(cin), 
        .sum(sum_behav), .cout(cout_behav)
    );

    initial begin  
        a = 0; b = 0; cin = 0; #10;
        a = 0; b = 0; cin = 1; #10;
        a = 0; b = 1; cin = 0; #10;
        a = 0; b = 1; cin = 1; #10;
        a = 1; b = 0; cin = 0; #10;
        a = 1; b = 0; cin = 1; #10;
        a = 1; b = 1; cin = 0; #10;
        a = 1; b = 1; cin = 1; #10;
        $finish;
    end
endmodule
module full_adder_struct (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);
    wire w_sum1;
    wire w_cout1;
    wire w_cout2;

    half_adder ha1 (
       .a    (a),
       .b    (b),
       .sum  (w_sum1),
       .cout (w_cout1)
    );

    half_adder ha2 (
        .a    (w_sum1),
        .b    (cin),
        .sum  (sum),
        .cout (w_cout2)
    );

    or u_or1 (cout, w_cout1, w_cout2);
endmodule

module full_adder_gate (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);
    wire w_xor1, w_and1, w_and2;
    xor u_xor1 (w_xor1, a, b);
    xor u_xor2 (sum, w_xor1, cin);
    and u_and1 (w_and1, a, b);
    and u_and2 (w_and2, w_xor1, cin);
    or  u_or1  (cout, w_and1, w_and2);
endmodule

module FullAdder2bit_Gate (
    input  [1:0] A,
    input  [1:0] B,
    input        Cin,
    output [1:0] Sum_GL,
    output       Cout_GL
);
    wire c1;
    
    wire w1, w2, w3;
    xor g1 (w1, A[0], B[0]);
    xor g2 (Sum_GL[0], w1, Cin);
    and g3 (w2, A[0], B[0]);
    and g4 (w3, w1, Cin);
    or  g5 (c1, w2, w3);
   
    wire w4, w5, w6;
    xor g6 (w4, A[1], B[1]);
    xor g7 (Sum_GL[1], w4, c1);
    and g8 (w5, A[1], B[1]);
    and g9 (w6, w4, c1);
    or  g10 (Cout_GL, w5, w6);

endmodule
module FullAdder2bit_Behav (
    input  [1:0] A,
    input  [1:0] B,
    input        Cin,
    output reg [1:0] Sum_Behav,
    output reg       Cout_Behav
);
    always @(*) begin
        {Cout_Behav, Sum_Behav} = A + B + Cin;
    end
endmodule
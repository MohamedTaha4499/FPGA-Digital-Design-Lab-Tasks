`timescale 1ns / 1ps

module tb_FullAdder;

    // inputs
    reg [1:0] A;
    reg [1:0] B;
    reg       Cin;

    // outputs for gate level
    wire [1:0] Sum_GL;
    wire       Cout_GL;

    // outputs for behavioral
    wire [1:0] Sum_Behav;
    wire       Cout_Behav;

    // outputs for structural
    wire [1:0] Sum_Struct;
    wire       Cout_Struct;

    FullAdder_GL uut_gate (
        .A(A), .B(B), .Cin(Cin),
        .Sum_GL(Sum_GL), .Cout_GL(Cout_GL)
    );
   
    FullAdder_Behav uut_behav (
        .A(A), .B(B), .Cin(Cin),
        .Sum_Behav(Sum_Behav), .Cout_Behav(Cout_Behav)
    );
   
    FullAdder_Struct uut_struct (
        .A(A), .B(B), .Cin(Cin),
        .Sum_Struct(Sum_Struct), .Cout_Struct(Cout_Struct)
    );

    integer i, j, k;

    initial begin
        $display("Time | A B Cin | GL: Sum Cout | Behav: Sum Cout | Struct: Sum Cout");
               
        for (i = 0; i < 4; i = i + 1) begin
            for (j = 0; j < 4; j = j + 1) begin
                for (k = 0; k < 2; k = k + 1) begin
                    A = i;
                    B = j;
                    Cin = k;
                    #10;
                    
                    $display("%4t | %b %b  %b  |   %b    %b   |    %b     %b    |    %b     %b", 
                             $time, A, B, Cin, 
                             Sum_GL, Cout_GL, 
                             Sum_Behav, Cout_Behav, 
                             Sum_Struct, Cout_Struct);
                end
            end
        end

        $finish;
    end

endmodule
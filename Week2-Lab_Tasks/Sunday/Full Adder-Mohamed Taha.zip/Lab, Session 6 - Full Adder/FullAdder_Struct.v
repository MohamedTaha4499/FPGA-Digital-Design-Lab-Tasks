module FullAdder1bit_Sub (
    input  a, b, cin,
    output sum, cout
);
    assign sum  = a ^ b ^ cin;
    assign cout = (a & b) | (cin & (a ^ b));
endmodule

module FullAdder2bit_Struct (
    input  [1:0] A,
    input  [1:0] B,
    input        Cin,
    output [1:0] Sum_Struct,
    output       Cout_Struct
);
    wire c1;
    
    FullAdder1bit_Sub FA0 (
        .a(A[0]),
        .b(B[0]),
        .cin(Cin),
        .sum(Sum_Struct[0]),
        .cout(c1)
    );
    
    FullAdder1bit_Sub FA1 (
        .a(A[1]),
        .b(B[1]),
        .cin(c1),
        .sum(Sum_Struct[1]),
        .cout(Cout_Struct)
    );

endmodule
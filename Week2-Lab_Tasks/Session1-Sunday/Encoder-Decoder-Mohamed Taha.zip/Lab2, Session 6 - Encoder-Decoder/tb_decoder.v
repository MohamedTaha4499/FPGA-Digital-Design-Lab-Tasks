`timescale 1ns/1ps

module tb_decoder;

    parameter N = 2;

    reg En;
    reg [N-1:0] In;
    wire [(1<<N)-1:0] out;

    decoder #(.N(N)) uut (
        .En(En),
        .In(In),
        .out(out)
    );
    integer i;

    initial begin
        En = 0;
        In = 0;
        #10;

        En = 1;
        for (i = 0; i < (1<<N); i = i + 1) begin
            In = i;
            #10;
        end

        $finish;
    end
endmodule
module decoder #(
    parameter N = 2
)(
    input wire En,
    input wire [N-1:0] In,
    output reg [(1<<N)-1:0] out
);
    always @(*) begin
        if (En)
            out = 1'b1 << In;
        else
            out = 0;
    end
endmodule
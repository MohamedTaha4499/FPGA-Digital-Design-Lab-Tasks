module encoder #(
    parameter N = 2
)(
    input wire En,
    input wire [(1<<N)-1:0] In,
    output reg [N-1:0] out
);
    integer i;

    always @(*) begin
        out = 0;
        if (En) begin
            for (i = 0; i < (1<<N); i = i + 1) begin
                if (In[i])
                    out = i;
            end
        end
    end
endmodule
`timescale 1ns/1ps

module tb_encoder;

    parameter N = 2;

    reg En;
    reg [(1<<N)-1:0] In;
    wire [N-1:0] out;

    encoder #(.N(N)) uut (
        .En(En),
        .In(In),
        .out(out)
    );
    initial begin
        En = 0;
        In = 4'b0000;
        #10;

        En = 1;
        In = 4'b0001; #10;
        In = 4'b0010; #10;
        In = 4'b0100; #10;
        In = 4'b1000; #10;

        $finish;
    end
endmodule
module top_gray_to_7-seg #(
    parameter N = 4
)(
    input wire [N-1:0] gray_in,
    output wire [6:0] seg_out
);
    wire [N-1:0] bin_wire;

    gray2bin_beh #(.N(N)) u_gray2bin (
        .gray(gray_in),
        .bin(bin_wire)
    );
    bin2seg u_bin2seg (
        .bin(bin_wire[3:0]), 
        .seg(seg_out)
    );
endmodule
`timescale 1ns/1ps

module top_gray_to_7-seg_tb;

    parameter N = 4;

    reg [N-1:0] gray_in;
    wire [6:0] seg_out;
    wire [N-1:0] bin_internal;

    top_gray_to_7-seg #(.N(N)) uut (
        .gray_in(gray_in),
        .seg_out(seg_out)
    );
    assign bin_internal = uut.bin_wire;

    integer i;

    initial begin
        gray_in = 0;
        #10;
        
        for (i = 0; i < 16; i = i + 1) begin
            gray_in = i;
            #10;
        end        
        $finish;
    end
endmodule
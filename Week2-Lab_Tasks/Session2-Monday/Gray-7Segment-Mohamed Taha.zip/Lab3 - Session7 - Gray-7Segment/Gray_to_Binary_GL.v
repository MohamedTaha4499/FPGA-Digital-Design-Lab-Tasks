module gray_to_bin_GL #(
    input wire [3:0] gray,
    output wire [3:0] bin
);
    assign bin[3] = gray[3];
    xor u2 (bin[2], bin[3], gray[2]); // Calculates bit 2
    xor u1 (bin[1], bin[2], gray[1]); // Calculates bit 1
    xor u0 (bin[0], bin[1], gray[0]); // Calculates bit 0
endmodule
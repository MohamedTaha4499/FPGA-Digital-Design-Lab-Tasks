module clk_divider #(
    parameter DIVISOR = 6250000               // 50000000/8 = 6250000
)(
    input wire clk_50M,
    input wire reset_n,
    output reg clk_out
);
    reg [31:0] count;

    always @(posedge clk_50M or negedge reset_n) begin
        if (!reset_n) begin
            count <= 0;
            clk_out <= 0;
        end else begin           
            if (count >= (DIVISOR / 2) - 1) begin
                clk_out <= ~clk_out;
                count <= 0;
            end else begin
                count <= count + 1;
            end
        end
    end
endmodule
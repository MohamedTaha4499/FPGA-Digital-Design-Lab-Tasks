module shift_register #(
    parameter N = 10
)(
    input wire clk,
    input wire reset_n,
    input wire hold_n,
    output reg [N-1:0] shift_out
);
    always @(posedge clk or negedge reset_n) begin
        if (!reset_n) begin            
            shift_out <= 1 << (N - 1); 
        end else if (hold_n) begin            
            shift_out <= {shift_out[0], shift_out[N-1:1]};
        end
    end
endmodule
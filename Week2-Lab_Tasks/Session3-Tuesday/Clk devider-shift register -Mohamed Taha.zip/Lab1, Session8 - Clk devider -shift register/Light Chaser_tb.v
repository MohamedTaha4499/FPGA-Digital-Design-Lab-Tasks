`timescale 1ns/1ps

module light_chaser_tb;

    parameter N = 10;
    parameter DIVISOR = 4;

    reg clk_50M;
    reg reset_n;
    reg hold_n;
    wire [N-1:0] shift_out;

    light_chaser #(
        .DIVISOR(DIVISOR),
        .N(N)
    ) uut (
        .clk_50M(clk_50M),
        .reset_n(reset_n),
        .hold_n(hold_n),
        .shift_out(shift_out)
    );

    initial begin
        clk_50M = 0;
        forever #10 clk_50M = ~clk_50M; 
    end

    
    initial begin
        
        reset_n = 0;
        hold_n = 1;
        #25;        

        reset_n = 1;
        #150;         

        hold_n = 0; 
        #80;        

        hold_n = 1; 
        #150;
        
        $finish;
    end
endmodule
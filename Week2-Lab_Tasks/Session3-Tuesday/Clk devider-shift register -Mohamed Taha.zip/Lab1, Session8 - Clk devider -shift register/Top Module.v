module light_chaser #(
    parameter DIVISOR = 6250000, 
    parameter N = 10
)(
    input wire clk_50M,
    input wire reset_n,
    input wire hold_n,
    output wire [N-1:0] shift_out
);
    wire clk_8Hz;
    
    clk_divider #(
        .DIVISOR(DIVISOR)
    ) u_clk_div (
        .clk_50M(clk_50M),
        .reset_n(reset_n),
        .clk_out(clk_8Hz)
    );
  
    shift_register #(
        .N(N)
    ) u_shift_reg (
        .clk(clk_8Hz),
        .reset_n(reset_n),
        .hold_n(hold_n),
        .shift_out(shift_out)
    );
endmodule
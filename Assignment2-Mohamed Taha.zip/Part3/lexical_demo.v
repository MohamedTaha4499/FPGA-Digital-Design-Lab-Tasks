/*
    Lab: Verilog Lexical Conventions
    Description: Demonstrates identifiers, numbers, strings, and attributes.
*/

// Add a module-level attribute here
(* optimize = "off" *)
module lexical_demo;

    // 1. Strings
    // A string requires 8 bits per character. "Hello World" is 11 characters (88 bits).
    reg [87:0] my_string;

    // 2. Case Sensitivity & Identifiers
    // Declare two 8-bit registers named 'Data_Val' and 'data_val'
    reg [7:0] Data_Val;
    reg [7:0] data_val;

    // 3. Logic Values & Literal Integers
    // Declare a 12-bit register named 'mixed_logic'
    reg [11:0] mixed_logic;

    // 4. Literal Real Numbers
    // Declare a 'real' variable named 'analog_voltage'
    real analog_voltage;

    // 5. Attributes on variables
    // use (* keep = "true" *) to a net called 'protected_wire'
    (* keep = "true" *) wire protected_wire;

    initial begin
        // --- Assignments ---
        
        // String assignment
        my_string = "Hello World";

        // Case Sensitive Assignment
        Data_Val = 8'hAA; 
        data_val = 8'h55;

        // Mixed Logic Assignment (1, 0, x, z)
        mixed_logic = 12'b1010_xxxx_zzzz;

        // Real Number Assignment
        analog_voltage = 3.3e-3;

        // --- Display Results ---
        // $display statements automatically print to the console.
        $display("--- Lexical Conventions Output ---");
        $display("String Value: %s", my_string);
        
        // Add $display statements to print variables.
        $display("Data_Val (Hex): %h", Data_Val);
        $display("data_val (Hex): %h", data_val);
        $display("Mixed Logic (Bin): %b", mixed_logic);
        $display("Analog Voltage (Real): %f", analog_voltage);
        
        $finish;
    end
endmodule
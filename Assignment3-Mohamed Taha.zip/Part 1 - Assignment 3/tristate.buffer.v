module tristate_buffer (
    input  wire       tx_en,
    input  wire [7:0] tx_data,
    inout  wire [7:0] shared_bus
);

    assign shared_bus = tx_en ? tx_data : 8'bz;

endmodule
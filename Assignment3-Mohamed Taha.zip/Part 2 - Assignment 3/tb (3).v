`timescale 1ns / 1ps

module tb;

    // Data Router Signals
    reg  [31:0] dr_data_in;
    wire [7:0]  dr_byte_low, dr_byte_high;
    wire        dr_parity_bit;

    // Reg File Signals
    reg         clk;
    reg  [2:0]  rf_read_addr, rf_write_addr;
    reg  [15:0] rf_write_data;
    reg         rf_we;
    wire [15:0] rf_read_data;
    wire [7:0]  rf_top_byte;

    // Grid Mem Router Signals
    reg         gmr_rst, gmr_oe, gmr_endian_swap;
    reg  [1:0]  gmr_row;
    reg         gmr_col;
    wire [31:0] gmr_proc_word;
    wire [7:0]  gmr_bus_data;

    // Device Under Test Instantiations
    data_router u_dr (
        .data_in(dr_data_in),
        .byte_low(dr_byte_low),
        .byte_high(dr_byte_high),
        .parity_bit(dr_parity_bit)
    );

    reg_file u_rf (
        .clk(clk),
        .read_addr(rf_read_addr),
        .write_addr(rf_write_addr),
        .write_data(rf_write_data),
        .we(rf_we),
        .read_data(rf_read_data),
        .read_data_top_byte(rf_top_byte)
    );

    grid_mem_router u_gmr (
        .clk(clk),
        .Rst(gmr_rst),
        .oe(gmr_oe),
        .endian_swap(gmr_endian_swap),
        .row_addr(gmr_row),
        .col_addr(gmr_col),
        .processing_word(gmr_proc_word),
        .bus_data(gmr_bus_data)
    );

    // Clock Generation (100MHz)
    always #5 clk = ~clk;

    initial begin
        // Initialize
        clk = 0;
        dr_data_in = 32'hA1B2C3D4;
        rf_we = 0; rf_read_addr = 0; rf_write_addr = 0; rf_write_data = 0;
        gmr_rst = 1; gmr_oe = 0; gmr_endian_swap = 0; gmr_row = 0; gmr_col = 0;

        #15 gmr_rst = 0;

        // Test Task 1: Data Router
        #10;
        $display("[DR] Byte High: %h (Expected: A1), Byte Low: %h (Expected: D4)", dr_byte_high, dr_byte_low);

        // Test Task 2: Reg File
        #10;
        rf_write_addr = 3'b010;
        rf_write_data = 16'hDE89;
        rf_we = 1;
        #10;
        rf_we = 0;
        rf_read_addr = 3'b010;
        #5;
        $display("[RF] Read Data: %h (Expected: DE89), Top Byte: %h (Expected: DE)", rf_read_data, rf_top_byte);

        // Test Task 3: Grid Memory Router
        #10;
        u_gmr.fabric_mem[0][0] = 8'h11;
        u_gmr.fabric_mem[1][0] = 8'h22;
        u_gmr.fabric_mem[2][0] = 8'h33;
        u_gmr.fabric_mem[3][0] = 8'h44;

        gmr_oe = 1; gmr_row = 2'b01; gmr_col = 1'b0;
        #10;
        $display("[GMR] Bus Data: %h (Expected: 22)", gmr_bus_data);

        gmr_endian_swap = 0; #10;
        $display("[GMR] Proc Word Normal (+:): %h (Expected: 44332211)", gmr_proc_word);

        gmr_endian_swap = 1; #10;
        $display("[GMR] Proc Word Swapped (-:): %h (Expected: 11223344)", gmr_proc_word);

        $finish;
    end

endmodule